// Lightweight local test harness for middleware.js.
//
// Run with: node test/middleware.test.mjs
//
// This exercises the real middleware against constructed Web `Request`
// objects (Node 18+ has global Request/Response/URL). It does not spin up
// an actual Vercel Edge/Node runtime, so it cannot verify Vercel-specific
// platform behavior (e.g. that next() ultimately resolves to /404.html).
// It DOES verify: Accept-header parsing/negotiation correctness, response
// status codes, Content-Type, Vary headers, and Markdown body content for
// every code path the middleware can take.

import assert from 'node:assert/strict';
import middleware from '../middleware.js';

let passed = 0;
let failed = 0;

async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`ok  - ${name}`);
  } catch (err) {
    failed++;
    console.log(`FAIL - ${name}`);
    console.log(`      ${err.message}`);
  }
}

function req(path, accept) {
  const headers = {};
  if (accept !== undefined && accept !== null) headers['accept'] = accept;
  return new Request(`https://www.vividpartners.ca${path}`, { headers });
}

async function run() {
  // --- Known page, browser-style Accept header -> HTML passthrough ---
  await test('browser Accept on known page -> next()/html, Vary set', async () => {
    const res = await middleware(
      req('/', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'),
    );
    assert.equal(res.headers.get('vary'), 'Accept, Accept-Encoding');
    // next() responses carry no content-type of their own; markdown must NOT be served
    assert.notEqual(res.headers.get('content-type'), 'text/markdown; charset=utf-8');
  });

  // --- Known page, explicit markdown request ---
  await test('Accept: text/markdown on "/" -> markdown body + headers', async () => {
    const res = await middleware(req('/', 'text/markdown'));
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('content-type'), 'text/markdown; charset=utf-8');
    assert.equal(res.headers.get('vary'), 'Accept, Accept-Encoding');
    const body = await res.text();
    assert.match(body, /^---\ntitle: /);
    assert.match(body, /# Vivid Partners/);
  });

  await test('Accept: text/markdown on "/team" -> team markdown', async () => {
    const res = await middleware(req('/team', 'text/markdown'));
    assert.equal(res.status, 200);
    const body = await res.text();
    assert.match(body, /Mithun Narendran/);
  });

  await test('trailing slash normalizes ("/team/" == "/team")', async () => {
    const res = await middleware(req('/team/', 'text/markdown'));
    assert.equal(res.status, 200);
    const body = await res.text();
    assert.match(body, /Mithun Narendran/);
  });

  // --- Markdown preferred over HTML via q-values ---
  await test('text/markdown q=1 beats text/html q=0.9 -> markdown', async () => {
    const res = await middleware(req('/contact', 'text/markdown, text/html;q=0.9'));
    assert.equal(res.headers.get('content-type'), 'text/markdown; charset=utf-8');
  });

  await test('text/markdown q=0.5 loses to text/html q=0.9 -> html/next()', async () => {
    const res = await middleware(req('/contact', 'text/markdown;q=0.5, text/html;q=0.9'));
    assert.notEqual(res.headers.get('content-type'), 'text/markdown; charset=utf-8');
  });

  await test('bare */* (default curl) -> html, not markdown', async () => {
    const res = await middleware(req('/', '*/*'));
    assert.notEqual(res.headers.get('content-type'), 'text/markdown; charset=utf-8');
  });

  await test('missing Accept header entirely -> html, not markdown', async () => {
    const res = await middleware(req('/', null));
    assert.notEqual(res.headers.get('content-type'), 'text/markdown; charset=utf-8');
  });

  // --- 406 Not Acceptable ---
  await test('Accept: application/pdf only -> 406', async () => {
    const res = await middleware(req('/', 'application/pdf'));
    assert.equal(res.status, 406);
    assert.equal(res.headers.get('vary'), 'Accept, Accept-Encoding');
    const body = await res.json();
    assert.deepEqual(body.available, ['text/html', 'text/markdown']);
  });

  // --- Unmatched path -> negotiated 404 ---
  await test('unknown path + Accept: text/markdown -> 404 + markdown recovery body', async () => {
    const res = await middleware(req('/some-path-that-does-not-exist', 'text/markdown'));
    assert.equal(res.status, 404);
    assert.equal(res.headers.get('content-type'), 'text/markdown; charset=utf-8');
    const body = await res.text();
    assert.match(body, /# 404 - Page Not Found/);
    assert.match(body, /\[Sitemap\]\(https:\/\/www\.vividpartners\.ca\/sitemap\.xml\)/);
    assert.match(body, /\[llms\.txt/);
  });

  await test('unknown path + browser Accept -> next() (platform 404.html), status not swallowed', async () => {
    const res = await middleware(
      req('/some-path-that-does-not-exist', 'text/html,application/xhtml+xml'),
    );
    // next() doesn't carry its own status in this harness (that's decided
    // by the platform's static routing), but it must not be a 200 with
    // markdown content-type, and Vary must still be attached.
    assert.equal(res.headers.get('vary'), 'Accept, Accept-Encoding');
  });

  // --- All 18 sitemap pages resolve to non-empty markdown ---
  const { PAGES } = await import('../lib/content.js');
  for (const route of Object.keys(PAGES)) {
    await test(`markdown negotiation works for ${route}`, async () => {
      const res = await middleware(req(route, 'text/markdown'));
      assert.equal(res.status, 200);
      const body = await res.text();
      assert.ok(body.length > 100, `expected substantial markdown body for ${route}`);
      assert.match(body, /^---\ntitle: /);
    });
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

run();
