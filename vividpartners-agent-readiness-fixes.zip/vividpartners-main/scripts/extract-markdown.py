"""Regenerate lib/content.js from the site's HTML pages.

Run this whenever page copy changes, so the Markdown served via
`Accept: text/markdown` (see /middleware.js) stays in sync with the HTML.

Usage:
    pip install beautifulsoup4 markdownify --break-system-packages
    python3 scripts/extract-markdown.py

This writes pages.json (a debug artifact you can inspect/diff) next to this
script. To actually update the site, take that output and re-run the
"build lib/content.js" step documented in README-agent-readiness.md, or ask
an engineer/AI assistant to regenerate lib/content.js from pages.json.
"""
import json, re, os
from bs4 import BeautifulSoup
from markdownify import markdownify as md

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = "https://www.vividpartners.ca"

ROUTES = {
    "/": "index.html",
    "/team": "team.html",
    "/portfolio": "portfolio.html",
    "/partner-stories": "partner-stories.html",
    "/careers": "careers.html",
    "/resources": "resources.html",
    "/contact": "contact.html",
    "/team-mithun": "team-mithun.html",
    "/team-abishan": "team-abishan.html",
    "/team-vathusan": "team-vathusan.html",
    "/team-rathusan": "team-rathusan.html",
    "/privacy": "privacy.html",
    "/terms": "terms.html",
    "/selling-your-business-in-ontario": "selling-your-business-in-ontario.html",
    "/what-is-a-holding-company": "what-is-a-holding-company.html",
    "/holding-company-vs-private-equity": "holding-company-vs-private-equity.html",
    "/how-small-businesses-are-valued": "how-small-businesses-are-valued.html",
    "/succession-planning-canada": "succession-planning-canada.html",
}

def clean_html_for_markdown(soup):
    # Remove non-content elements
    for sel in ["script", "style", "noscript", "svg", "form"]:
        for tag in soup.find_all(sel):
            tag.decompose()
    for tag in soup.find_all("header", class_="site-header"):
        tag.decompose()
    for tag in soup.find_all("footer", class_="site-footer"):
        tag.decompose()
    for tag in soup.find_all(attrs={"id": "mobileNavPanel"}):
        tag.decompose()
    for tag in soup.find_all(class_="mobile-nav-toggle"):
        tag.decompose()
    for tag in soup.find_all(class_="footer-back-to-top"):
        tag.decompose()
    for cls in ["quote-mark", "who-we-are-bg-num", "portfolio-arrows",
                "testimonial-nav", "testimonial-dots", "faq-toggle",
                "testimonial-avatar"]:
        for tag in soup.find_all(class_=cls):
            tag.decompose()
    # Drop any now-empty inline/leaf elements left over (e.g. an <h3> whose
    # text content is populated client-side via JS and is empty in raw HTML)
    for tag in soup.find_all(["h1", "h2", "h3", "h4", "span", "div", "p", "button"]):
        if not tag.get_text(strip=True) and not tag.find("img"):
            tag.decompose()
    return soup

def extract(route, filename):
    path = os.path.join(SRC, filename)
    html = open(path, encoding="utf-8").read()
    soup = BeautifulSoup(html, "html.parser")

    title_tag = soup.find("title")
    title = title_tag.get_text(strip=True) if title_tag else "Vivid Partners"

    desc_tag = soup.find("meta", attrs={"name": "description"})
    description = desc_tag["content"].strip() if desc_tag and desc_tag.get("content") else ""

    canonical_tag = soup.find("link", attrs={"rel": "canonical"})
    canonical = canonical_tag["href"] if canonical_tag and canonical_tag.get("href") else (BASE + route)

    body = soup.find("body")
    body = clean_html_for_markdown(body)

    body_html = str(body)
    markdown_body = md(body_html, heading_style="ATX", bullets="-", strip=["a"] if False else None)

    # markdownify keeps links by default; don't strip. Remove the `strip=` kw misuse above.
    markdown_body = md(body_html, heading_style="ATX", bullets="-")

    # Clean up excess blank lines / whitespace
    lines = [ln.rstrip() for ln in markdown_body.split("\n")]
    cleaned = []
    blank_run = 0
    for ln in lines:
        if ln.strip() == "":
            blank_run += 1
            if blank_run > 1:
                continue
        else:
            blank_run = 0
        cleaned.append(ln)
    markdown_body = "\n".join(cleaned).strip()

    # Remove stray "()" empty link artifacts and repeated backslash-escapes markdownify sometimes adds
    markdown_body = re.sub(r'\\([_*\[\]()#+.!-])', r'\1', markdown_body)
    markdown_body = re.sub(r'\n{3,}', '\n\n', markdown_body)

    frontmatter = (
        "---\n"
        f"title: {title}\n"
        f"url: {canonical}\n"
        + (f"description: {description}\n" if description else "")
        + "---\n\n"
    )

    full_md = frontmatter + markdown_body + "\n"
    return {
        "title": title,
        "description": description,
        "canonical": canonical,
        "markdown": full_md,
    }

if __name__ == "__main__":
    result = {}
    for route, filename in ROUTES.items():
        result[route] = extract(route, filename)
        print(f"{route:45s} -> {len(result[route]['markdown']):6d} chars, title={result[route]['title'][:60]}")
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pages.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"\nWrote {out_path}")
